"""Metrics: sketch preservation (edge-based) and prompt fidelity (CLIP score)."""
from __future__ import annotations

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image


def canny_edges(img: Image.Image, low: int = 100, high: int = 200) -> np.ndarray:
    gray = np.array(img.convert("L"))
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    return cv2.Canny(gray, low, high) > 0


def sketch_preservation(control: Image.Image, output: Image.Image, tol: int = 6) -> dict:
    """Compare the control sketch (white lines) with Canny edges of the generated image.

    recall    : share of sketch pixels lying within `tol` px of an output edge (main metric)
    precision : share of output edge pixels within `tol` px of the sketch (low is normal:
                the model adds texture/detail edges the sketch does not contain)
    iou       : IoU of the two tolerance-dilated edge maps
    chamfer   : mean distance (px) from each sketch pixel to the nearest output edge (lower = better)
    """
    s = np.array(control.convert("L")) > 127
    o = canny_edges(output.resize(control.size))
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * tol + 1, 2 * tol + 1))
    s_d = cv2.dilate(s.astype(np.uint8), k) > 0
    o_d = cv2.dilate(o.astype(np.uint8), k) > 0
    dist = cv2.distanceTransform((~o).astype(np.uint8), cv2.DIST_L2, 3)
    return {
        "recall": float((s & o_d).sum() / max(s.sum(), 1)),
        "precision": float((o & s_d).sum() / max(o.sum(), 1)),
        "iou": float((s_d & o_d).sum() / max((s_d | o_d).sum(), 1)),
        "chamfer": float(dist[s].mean()) if s.any() else float("nan"),
    }


class ClipScorer:
    """CLIP score = 100 * cosine(image_emb, text_emb)."""

    def __init__(self, model_id: str = "openai/clip-vit-base-patch32"):
        from transformers import CLIPModel, CLIPProcessor

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = CLIPModel.from_pretrained(model_id).to(self.device).eval()
        self.proc = CLIPProcessor.from_pretrained(model_id)

    @torch.no_grad()
    def __call__(self, image: Image.Image, text: str) -> float:
        inputs = self.proc(text=[text], images=image, return_tensors="pt", padding=True, truncation=True)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        out = self.model(**inputs)
        return 100.0 * F.cosine_similarity(out.image_embeds, out.text_embeds).item()

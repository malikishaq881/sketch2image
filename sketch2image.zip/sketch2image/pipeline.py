"""Sketch-to-image pipeline: Stable Diffusion 1.5 + ControlNet (scribble)."""
from __future__ import annotations

import cv2
import numpy as np
import torch
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline, UniPCMultistepScheduler
from PIL import Image, ImageOps

BASE_MODEL = "stable-diffusion-v1-5/stable-diffusion-v1-5"
CONTROLNET_MODEL = "lllyasviel/control_v11p_sd15_scribble"

DEFAULT_NEGATIVE = "lowres, blurry, deformed, extra limbs, text, watermark, bad anatomy, cropped"


def get_device() -> str:
    return "cuda" if torch.cuda.is_available() else "cpu"


def load_pipeline(base_model: str = BASE_MODEL, controlnet_model: str = CONTROLNET_MODEL):
    """Load SD1.5 with a ControlNet branch. fp16 on GPU, fp32 on CPU."""
    device = get_device()
    dtype = torch.float16 if device == "cuda" else torch.float32
    controlnet = ControlNetModel.from_pretrained(controlnet_model, torch_dtype=dtype)
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        base_model, controlnet=controlnet, torch_dtype=dtype, safety_checker=None
    )
    pipe.scheduler = UniPCMultistepScheduler.from_config(pipe.scheduler.config)
    pipe.to(device)
    return pipe


def preprocess_sketch(img: Image.Image, size: int = 512, thicken: int = 1) -> Image.Image:
    """Convert a sketch into a ControlNet scribble map: white lines on black, size x size.

    - handles dark-on-light (paper) and light-on-dark sketches
    - pads to a square without distorting the aspect ratio
    - binarises and optionally thickens the strokes (thin pencil lines get lost otherwise)
    """
    gray = ImageOps.autocontrast(img.convert("L"))
    light_bg = np.array(gray).mean() > 127
    fill = 255 if light_bg else 0
    gray = ImageOps.contain(gray, (size, size), Image.LANCZOS)
    canvas = Image.new("L", (size, size), fill)
    canvas.paste(gray, ((size - gray.width) // 2, (size - gray.height) // 2))
    if light_bg:
        canvas = ImageOps.invert(canvas)
    arr = (np.array(canvas) > 100).astype(np.uint8) * 255
    if thicken > 0:
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * thicken + 1, 2 * thicken + 1))
        arr = cv2.dilate(arr, kernel)
    return Image.fromarray(arr).convert("RGB")


def generate(
    pipe,
    control: Image.Image,
    prompt: str,
    negative_prompt: str = DEFAULT_NEGATIVE,
    steps: int = 30,
    guidance: float = 7.5,
    cond_scale: float = 1.0,
    seed: int = 42,
    size: int = 512,
) -> Image.Image:
    """Run one generation.

    steps       : denoising steps
    guidance    : classifier-free guidance scale (prompt strength)
    cond_scale  : ControlNet conditioning scale (how strongly the sketch is enforced)
    """
    generator = torch.Generator(device="cpu").manual_seed(int(seed))
    out = pipe(
        prompt=prompt,
        negative_prompt=negative_prompt,
        image=control,
        num_inference_steps=int(steps),
        guidance_scale=float(guidance),
        controlnet_conditioning_scale=float(cond_scale),
        generator=generator,
        height=size,
        width=size,
    )
    return out.images[0]

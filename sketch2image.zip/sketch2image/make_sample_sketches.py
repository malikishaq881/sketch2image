"""Create 3 simple placeholder sketches (building, robot, lamp) in sketches/.
Replace them with your own hand-drawn sketches for the final submission."""
from pathlib import Path

from PIL import Image, ImageDraw

out = Path("sketches")
out.mkdir(exist_ok=True)
W = 4


def canvas():
    im = Image.new("RGB", (512, 512), "white")
    return im, ImageDraw.Draw(im)


# building
im, d = canvas()
d.rectangle([180, 120, 330, 460], outline="black", width=W)
d.polygon([(180, 120), (255, 60), (330, 120)], outline="black", width=W)
d.line([255, 60, 255, 20], fill="black", width=W)
for y in range(150, 440, 45):
    for x in (200, 245, 290):
        d.rectangle([x, y, x + 25, y + 25], outline="black", width=3)
d.line([100, 460, 420, 460], fill="black", width=W)
im.save(out / "building.png")

# robot
im, d = canvas()
d.rectangle([190, 80, 320, 190], outline="black", width=W)
d.ellipse([215, 115, 245, 145], outline="black", width=W)
d.ellipse([265, 115, 295, 145], outline="black", width=W)
d.line([225, 170, 285, 170], fill="black", width=W)
d.line([255, 80, 255, 40], fill="black", width=W)
d.ellipse([245, 28, 265, 48], outline="black", width=W)
d.rectangle([170, 200, 340, 360], outline="black", width=W)
d.rectangle([110, 210, 165, 330], outline="black", width=W)
d.rectangle([345, 210, 400, 330], outline="black", width=W)
d.rectangle([195, 365, 245, 470], outline="black", width=W)
d.rectangle([265, 365, 315, 470], outline="black", width=W)
im.save(out / "robot.png")

# desk lamp
im, d = canvas()
d.ellipse([150, 420, 330, 470], outline="black", width=W)
d.line([240, 430, 240, 300], fill="black", width=W)
d.line([240, 300, 330, 190], fill="black", width=W)
d.polygon([(290, 150), (400, 210), (430, 140), (330, 90)], outline="black", width=W)
d.ellipse([228, 290, 252, 314], outline="black", width=W)
im.save(out / "lamp.png")
print("Saved 3 sample sketches in sketches/")

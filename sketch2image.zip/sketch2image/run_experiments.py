"""Run all experiments on every sketch in a folder and save images, grids and metrics.

Usage:
    python run_experiments.py --sketches sketches --out outputs [--prompts prompts.json] [--quick]
prompts.json (optional) maps a sketch file stem to a subject, e.g. {"building": "a futuristic skyscraper"}.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from PIL import Image, ImageDraw

from metrics import ClipScorer, sketch_preservation
from pipeline import DEFAULT_NEGATIVE, generate, load_pipeline, preprocess_sketch

STYLES = {
    "photorealistic": "photorealistic, ultra detailed, 8k, natural lighting, sharp focus",
    "cyberpunk": "cyberpunk style, neon lights, night, rain reflections, cinematic",
    "watercolor": "watercolor painting, soft pastel colors, paper texture, artistic",
}
DEFAULTS = dict(steps=30, guidance=7.5, cond_scale=1.0, seed=42)


def save_grid(images, labels, path, cell=256):
    pad = 22
    grid = Image.new("RGB", (cell * len(images), cell + pad), "white")
    draw = ImageDraw.Draw(grid)
    for i, (im, lb) in enumerate(zip(images, labels)):
        grid.paste(im.resize((cell, cell)), (i * cell, 0))
        draw.text((i * cell + 6, cell + 5), lb, fill="black")
    grid.save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sketches", default="sketches")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--prompts", default=None)
    ap.add_argument("--style", default="photorealistic", help="style used for the parameter sweeps")
    ap.add_argument("--quick", action="store_true", help="smaller sweeps for a fast test")
    args = ap.parse_args()

    out_root = Path(args.out)
    out_root.mkdir(parents=True, exist_ok=True)
    subjects = json.load(open(args.prompts)) if args.prompts else {}
    files = sorted(p for p in Path(args.sketches).iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"})
    assert files, f"No sketches found in {args.sketches}"

    cond_scales = [0.5, 1.0, 1.5] if args.quick else [0.3, 0.6, 1.0, 1.3, 1.6]
    guidances = [5, 7.5, 12] if not args.quick else [7.5]
    steps_list = [15, 30, 50] if not args.quick else [30]
    seeds = [1, 2, 3, 4] if not args.quick else [1, 2]

    pipe = load_pipeline()
    clip = ClipScorer()
    records = []

    for sk in files:
        stem = sk.stem
        subject = subjects.get(stem, stem.replace("_", " ").replace("-", " "))
        folder = out_root / stem
        folder.mkdir(exist_ok=True)
        control = preprocess_sketch(Image.open(sk))
        control.save(folder / "control.png")
        print(f"\n=== {stem}: '{subject}' ===")

        def run(experiment, variant, style=args.style, **kw):
            p = {**DEFAULTS, **kw}
            prompt = f"{subject}, {STYLES[style]}"
            img = generate(pipe, control, prompt, DEFAULT_NEGATIVE, **p)
            img.save(folder / f"{experiment}_{variant}.png")
            m = sketch_preservation(control, img)
            m["clip"] = clip(img, prompt)
            records.append(dict(sketch=stem, experiment=experiment, variant=str(variant), style=style, **p, **m))
            return img

        sweeps = {
            "style": [(s, dict(style=s)) for s in STYLES],
            "cond_scale": [(f"cs{c}", dict(cond_scale=c)) for c in cond_scales],
            "guidance": [(f"g{g}", dict(guidance=g)) for g in guidances],
            "steps": [(f"st{s}", dict(steps=s)) for s in steps_list],
            "seed": [(f"seed{s}", dict(seed=s)) for s in seeds],
        }
        for exp, variants in sweeps.items():
            if len(variants) < 2 and exp != "style":
                continue
            imgs = [run(exp, name, **kw) for name, kw in variants]
            save_grid([control] + imgs, ["sketch"] + [n for n, _ in variants], folder / f"grid_{exp}.png")

    df = pd.DataFrame(records)
    df.to_csv(out_root / "results.csv", index=False)

    # Summary plot: effect of ControlNet conditioning scale
    cs = df[df.experiment == "cond_scale"].groupby("cond_scale")[["recall", "iou", "clip"]].mean()
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.5))
    cs[["recall", "iou"]].plot(ax=ax[0], marker="o", title="Sketch preservation vs conditioning scale")
    cs[["clip"]].plot(ax=ax[1], marker="o", color="tab:green", title="CLIP score vs conditioning scale")
    for a in ax:
        a.set_xlabel("controlnet_conditioning_scale")
    plt.tight_layout()
    plt.savefig(out_root / "plot_cond_scale.png", dpi=150)

    print("\nMean metrics per experiment:")
    print(df.groupby(["experiment", "variant"])[["recall", "iou", "chamfer", "clip"]].mean().round(3))
    print(f"\nDone. Results in {out_root}/")


if __name__ == "__main__":
    main()

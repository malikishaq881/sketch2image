"""Gradio demo: upload a sketch + prompt -> generated image.  python app.py [--share]"""
from __future__ import annotations

import argparse

import gradio as gr

from metrics import sketch_preservation
from pipeline import DEFAULT_NEGATIVE, generate, load_pipeline, preprocess_sketch
from run_experiments import STYLES

pipe = None


def run(sketch, subject, style, extra, cond_scale, guidance, steps, seed):
    global pipe
    if sketch is None:
        raise gr.Error("Please upload a sketch.")
    if pipe is None:
        pipe = load_pipeline()
    control = preprocess_sketch(sketch)
    prompt = ", ".join(x for x in [subject, STYLES[style], extra] if x)
    img = generate(pipe, control, prompt, DEFAULT_NEGATIVE, steps, guidance, cond_scale, seed)
    m = sketch_preservation(control, img)
    return control, img, f"Sketch recall: {m['recall']:.2f} | IoU: {m['iou']:.2f} | Chamfer: {m['chamfer']:.1f}px"


with gr.Blocks(title="Sketch to Image") as demo:
    gr.Markdown("# Sketch → Image (Stable Diffusion 1.5 + ControlNet Scribble)")
    with gr.Row():
        with gr.Column():
            sketch = gr.Image(type="pil", label="Sketch (dark lines on light paper works best)")
            subject = gr.Textbox(label="Subject", placeholder="a futuristic skyscraper")
            style = gr.Dropdown(list(STYLES), value="photorealistic", label="Style")
            extra = gr.Textbox(label="Extra prompt (optional)", placeholder="sunset, glass and steel")
            cond = gr.Slider(0.0, 2.0, 1.0, step=0.1, label="ControlNet conditioning scale")
            guid = gr.Slider(1, 20, 7.5, step=0.5, label="Guidance scale")
            steps = gr.Slider(10, 60, 30, step=1, label="Steps")
            seed = gr.Number(42, label="Seed", precision=0)
            btn = gr.Button("Generate", variant="primary")
        with gr.Column():
            ctrl = gr.Image(label="Control map")
            result = gr.Image(label="Result")
            info = gr.Textbox(label="Metrics")
    btn.click(run, [sketch, subject, style, extra, cond, guid, steps, seed], [ctrl, result, info])

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--share", action="store_true")
    demo.launch(share=ap.parse_args().share)
